/*
 * Copyright (C)2005-2018 Haxe Foundation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

package js.lib;

@:native("Error")
extern class Error {
	var message:String;
	var name:String;
	var stack(default, null):String;

	function new(?message:String):Void;
}

@:native("EvalError")
extern class EvalError extends Error {
	function new(?message:String):Void;
}

@:native("RangeError")
extern class RangeError extends Error {
	function new(?message:String):Void;
}

@:native("ReferenceError")
extern class ReferenceError extends Error {
	function new(?message:String):Void;
}

@:native("SyntaxError")
extern class SyntaxError extends Error {
	function new(?message:String):Void;
}

@:native("TypeError")
extern class TypeError extends Error {
	function new(?message:String):Void;
}

@:native("URIError")
extern class URIError extends Error {
	function new(?message:String):Void;
}
